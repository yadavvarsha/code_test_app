Project - CanvasPaintApp

__Description__

CanvasPaintApp is a simple console version of a drawing program that takes inputs from the user and draw on console according to the given commands. 
In a nutshell, the program works as follows:
 1. Create a new canvas
 2. Start drawing on the canvas by issuing various commands
 3. Quit


Command 		Description
C w h           creates a new canvas of width w and height h.
L x1 y1 x2 y2   creates a new line from (x1,y1) to (x2,y2). Currently only
                horizontal or vertical lines are supported. Horizontal and vertical lines
                will be drawn using the 'x' character. If y1==y2 then horizontal line will be drawn and if x1==x2 then vertical line will be drawn
R x1 y1 x2 y2   creates a new rectangle, whose upper left corner is (x1,y1) and
                lower right corner is (x2,y2). Horizontal and vertical lines will be drawn
                using the 'x' character.
B x y c         fills the entire area connected to (x,y) with "colour" c. The
                behavior of this is the same as that of the "bucket fill" tool in paint
                programs.
Q               quit the program.

How to install/run this project -

Jdk1.8 should be installed on the machine
Unzip the folder and import the project in any IDE(eclipse) and run the main Java file - CanvasPaintApplication.java
Once you run the main file, it will ask for the input saying "Enter the command to create and draw on Canvas" until you enter the valid inputs
It will create and draw on canvas as per the above mentioned commands

Test cases -

1) Input -  A 10 10  -> 	Output -First draw the canvas by entering valid command Starting with C followed by width(w) and height(h)
2) Input -  A 10     ->     Output -First draw the canvas by entering valid command Starting with C followed by width(w) and height(h)
3) Input - C -1 -12  ->     Output - Enter positive width and height
4) Input - C  test   ->     Output - draw the canvas by entering valid command Starting with C followed by width(w) and height(h)
5) Input - C w 10    ->     Output - draw the canvas by entering valid command Starting with C followed by width(w) and height(h)
6) Input - C 10      ->     It will wait for the third input
7) Input - C 20 4    ->     Output - Print the canvas on console of width 20 and height 4
8) Input - L 1 2 3 4 ->     Output - Enter the valid input either x1=x2 or y1=y2
9) Input - L 18 12 18 13 -> Output - Input is outside the canvas, coordinates should be within x1=> 1, X2 <=20, y1>=1, y2<= 4
10)Input - L 6 2 1 2  ->    Output  - x2 should be greater than x1
11) Input - L 1 2 6 2 ->    Output - Horizontal line will be printed on the console
12) Input - L 6 3 6 4 ->    Output - Vertical line will be printed on the console
13) Input - R 14 1 22 3 ->  Output - Input is outside the canvas, coordinates should be within x1> 1, X2 <20, y1>1, y2< 4
14) Input - R 15 1 12 3 ->  Output - End cordinates should be greater than starting cordinates
15) Input - R 14 1 18 3 ->  Output - Rectangle will be printed on the console
16) Input - B 23 3 o     -> Output - Input is outside the canvas, coordinates should be within x> 0, x <20, y>0, y< 4
17) Input - B 10 3 o ->      Output - Canvas will be filled with color o
18) Input - B 10 3 k  ->     Output - Canvas will be filled with color k
19) Input - B 14 1 o  ->     Output - If rectangle is already drawn then it will overwrite the boundry with color k on place of o
  
 


