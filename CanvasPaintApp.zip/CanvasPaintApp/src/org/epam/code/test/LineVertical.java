package org.epam.code.test;

public class LineVertical implements CanvasPaintOperation{

	private final int w,h,x1,y1,x2,y2;
	private final String[][] array;
	
	public LineVertical(int w, int h, int x1, int y1, int x2, int y2, String[][] array) {
		super();
		this.w = w;
		this.h = h;
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.array = array;
	}
	
// Check X1 is less than boundary 
	@Override
    public void draw() {
		if(y2 <y1) {
			System.out.println("y2 should be greater than y1");
		}else {
			int j=x1;
			for(int i=y1; i<=y2; i++) {
				if(i>= y1 && i< h-1) {
				array[i][j] = "x";
			}
		}
		
		Utility.printCanvas(w, h, array);}
}
}
