package org.epam.code.test.JUnit;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.epam.code.test.BucketFill;
import org.epam.code.test.Canvas;
import org.epam.code.test.CanvasPaintApplication;
import org.epam.code.test.CanvasPaintService;
import org.epam.code.test.LineHorizontal;
import org.epam.code.test.LineVertical;
import org.epam.code.test.Rectangle;
import org.junit.jupiter.api.Test;

class CanvasPaintJUnit {
	
  CanvasPaintService service = new CanvasPaintService();
  
	@Test
	void testCanvasWithLineRectangleBucketFill() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new LineHorizontal(w, h, 1, 2, 6, 2, array));
    service.drawCanvas(new LineVertical(w, h, 6,3,6,4, array));
    service.drawCanvas(new Rectangle(w, h,14,1,18,3, array));
    service.drawCanvas(new BucketFill(w, h,10,3,"O", array));
	}
	
	
	@Test
	void testHorizontalLine() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new LineHorizontal(w, h, 1, 2, 6, 2, array));
	}
	
	@Test
	void testHorizontalLineInvalidInput() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new LineHorizontal(w, h, 4, 2, 1, 2, array));
	}

	@Test
	void testVerticalLine() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new LineVertical(w, h, 6,3,6,4, array));
	}
	
	@Test
	void testVerticalLineInvalidInput() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new LineVertical(w, h, 6,6,6,4, array));
	}
	
	@Test
	void testRectangle() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new Rectangle(w, h,14,1,18,3, array));
	}
	
	@Test
	void testRectangleInvalidInput() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new Rectangle(w, h,14,4,18,3, array));
	}
	
	@Test
	void testBucketFill() {
	int h1=4;
    int w1 = 20;
    int h= h1+2;
    int w = w1+2;
    String [][] array = new String[h][w];	
    service.drawCanvas(new Canvas(w,h,array));	
    service.drawCanvas(new BucketFill(w, h,10,3,"O", array));
	}

}
