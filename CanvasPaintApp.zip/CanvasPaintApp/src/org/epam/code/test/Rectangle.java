package org.epam.code.test;

public class Rectangle implements CanvasPaintOperation{

	private final int w,h,x1,y1,x2,y2;
	private final String[][] array;
	
	public Rectangle(int w, int h, int x1, int y1, int x2, int y2, String[][] array) {
		super();
		this.w = w;
		this.h = h;
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.array = array;
	}
	

	@Override
    public void draw() {
       if(y2<=y1 || x2<=x1) {
    	   System.out.println("End cordinates should be greater than starting cordinates");
       }else {
		for(int i=0; i<h; i++) {
			
			int f=0;
			for(int j=0; j<w; j++) {
				if(i>=y1 && i<=y2 && j>= x1 && f<=x2-x1) {
					f++;
					if(i==y1 || i==y2 || j==x1 || j==x2) {
						array[i][j] = "x";
					}		
			}
		}
	}
		Utility.printCanvas(w, h, array);}
}
	
}
