package org.epam.code.test;

public interface CanvasPaintOperation {
	
	void draw();

}
