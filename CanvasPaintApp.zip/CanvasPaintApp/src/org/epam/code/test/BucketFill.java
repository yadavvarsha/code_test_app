package org.epam.code.test;

public class BucketFill implements CanvasPaintOperation {

	private final int w,h,x,y;
	private final String color;
	private final String[][] array;
	
	public BucketFill(int w, int h, int x, int y, String color, String[][] array) {
		super();
		this.w = w;
		this.h = h;
		this.x = x;
		this.y = y;
		this.color = color;
		this.array = array;
	}

	@Override
	public void draw() {
		String oldval = array[y][x];
		bucketFill(array,x,y,color, oldval);
		Utility.printCanvas(w, h, array);
		
		
	}
	
	public void bucketFill(String[][] array,int x,int y, String color, String oldval) {
	
		if(y<0 || y> h-1 || x<0 || x>w-1) {
			return;
		}
		
		if(array[y][x] != oldval) {
			return;
		}
		array[y][x] = color;
		
		bucketFill(array, x+1, y, color, oldval);
		bucketFill(array, x-1, y, color, oldval);
		bucketFill(array, x, y+1, color, oldval);
		bucketFill(array, x, y-1, color, oldval);
	}
	
}
