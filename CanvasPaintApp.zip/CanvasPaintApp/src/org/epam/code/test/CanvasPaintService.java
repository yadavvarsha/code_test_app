package org.epam.code.test;

public class CanvasPaintService {

	public void drawCanvas(CanvasPaintOperation operation) {
		operation.draw();
	}
}
