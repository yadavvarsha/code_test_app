package org.epam.code.test;

import java.util.Scanner;

public class CanvasPaintApplication {

	public static void main(String args[]) {
		char firstCahrInput = ' ';
		int w=0,h=0,x,y,x1,y1,x2,y2;
		boolean validInput = false;
		boolean drawCanvas = false;
		String [][] array = new String[0][0];
		CanvasPaintService service = new CanvasPaintService();
		do {
			System.out.println("Enter command to create and draw on canvas");
			Scanner sc = new Scanner(System.in);
			if(sc.hasNextLine()) {
				try {
					firstCahrInput = sc.next(".").charAt(0);
					if(firstCahrInput == 'C' && sc.hasNext() && sc.hasNext()) {
						w = sc.nextInt();
						h= sc.nextInt();
						
						if(h<=0 || w<=0) {
							System.out.println("Enter positive width and height");
						}else {
						validInput = true;
						h = h+2;
						w = w+2;
						array = new String [h][w];
						service.drawCanvas(new Canvas(w,h,array));
						drawCanvas=true;}
					}else if(drawCanvas && (firstCahrInput == 'L' || firstCahrInput =='R') && sc.hasNextInt() && sc.hasNextInt() && sc.hasNextInt() && sc.hasNextInt()) {
						x1 = sc.nextInt();
						y1 = sc.nextInt();
						x2 = sc.nextInt();
						y2 = sc.nextInt();
						validInput = true;
						if(firstCahrInput == 'L') {
							if(x1 < 1 || x2 > w-2 || y1 <1 || y2>h-2) {
								int w1 = w-2;
								int h1 = h-2;
								System.out.println("Input is outside the canvas, coordinates should be within x1=> 1, X2 <=" + w1 + ", y1>=1, y2<= " + h1);
							}
							else if(y1==y2) {
								service.drawCanvas(new LineHorizontal(w, h, x1, y1, x2, y2, array));
							}else if(x1==x2) {
								service.drawCanvas(new LineVertical(w, h, x1, y1, x2, y2, array));
							}else {
								System.out.println("Enter the valid input either x1=x2 or y1=y2");
							}
						}else {
							if(x1 <= 1 || x2 > w-2 || y1 <1 || y2>h-2) {
								int w1 = w-2;
								int h1 = h-2;
								System.out.println("Input is outside the canvas, coordinates should be within x1> 1, X2 <" + w1 + ", y1>1, y2< " + h1);
							}else {
								 
							service.drawCanvas(new Rectangle(w, h, x1, y1, x2, y2, array));}
						}
					}else if(drawCanvas && firstCahrInput == 'B' && sc.hasNextInt() && sc.hasNextInt()) {
							x = sc.nextInt();
							y= sc.nextInt();
							char c = sc.next().charAt(0);
							String color = Character.toString(c);
							int w1 = w-2;
							int h1 = h-2;
							if(x<0 || x>w-2 || y<0 || y>h-2) {
								System.out.println("Input is outside the canvas, coordinates should be within x> 0, x <" + w1 + ", y>0, y< " + h1);
							}else {
						    service.drawCanvas(new BucketFill(w, h, x, y, color, array));}
						
					}
					else if(firstCahrInput != 'Q'){
						System.out.println("First draw the canvas by entering valid command Starting with C followed by width(w) and height(h)");
					}
				}catch(Exception ex) {
					validInput = false;
					System.out.println("draw the canvas by entering valid command Starting with C followed by width(w) and height(h)");
				}
			}
		}while(!validInput || firstCahrInput != 'Q');
		System.out.println("Exit");
	}
}
