package org.epam.code.test;

public class Canvas implements CanvasPaintOperation{
	
	private final int w,h;
	private final String[][] array;
	

	public Canvas(int w, int h, String[][] array) {
		super();
		this.w = w;
		this.h = h;
		this.array = array;
	}

     @Override
     public void draw() {
    	 
		for(int i=0; i<h; i++) {
			for(int j=0; j<w; j++) {
				if(i==0 || i== h-1) {
					array[i][j] = "-";				
			    }else {
				if(j==0 || j==w-1) {
					array[i][j] = "|";
				}else {
					array[i][j] = " ";
				}
			}
		}
	}
     
		Utility.printCanvas(w, h, array);
     
 }
}