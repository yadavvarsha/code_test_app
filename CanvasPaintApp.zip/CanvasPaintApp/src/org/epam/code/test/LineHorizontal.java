package org.epam.code.test;

public class LineHorizontal implements CanvasPaintOperation {
	
	private final int w,h,x1,y1,x2,y2;
	private final String[][] array;
	
	public LineHorizontal(int w, int h, int x1, int y1, int x2, int y2, String[][] array) {
		super();
		this.w = w;
		this.h = h;
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.array = array;
	}

	@Override
    public void draw() {
		if(x2 <x1) {
			System.out.println("x2 should be greater than x1");
		}else {
			int i=y1;
			for(int j=x1; j<=x2; j++) {
				if(j>= x1 && j< w-1) {
				array[i][j] = "x";
				}
		}
			Utility.printCanvas(w, h, array);

		}
	}
	

}
