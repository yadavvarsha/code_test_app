package org.epam.code.test;

public class Utility {
	
	public static void printCanvas(int w, int h, String[][] array ) {
		for(int i=0; i<h ;i++) {
			for(int j=0; j<w; j++) {
				System.out.print(array[i][j]);
			}
			System.out.println();
		}
	}

}
